


/*

Program: ExamplefromClass.java          Last Date of this Revision: 23-Sep-2020

Purpose: 

Author: Your Name, 
School: CHHS
Course: Computer Programming 20
 
*/

package chapter2;


public class ExamplefromClass 
{
    public static void main(String[] args) 
    {
        /*System.out.print("Hello World!\n\n ");
        System.out.println("Crescent Heights");
        System.out.println("Team \t\t Standings \t\t Schedule");
        System.out.println("");
        */
       int z = 33;
       int x = 7;
       x = x + 3;
       x = z;
       System.out.println(x);
       
       double c = 5.6;
       
       char p = 'a';
       
       boolean light = true;
       
       
        
    }
    

}
/* Screen Dump
 
Hello World!

 Crescent Heights
Team 		 Standings 		 Schedule

 
 */