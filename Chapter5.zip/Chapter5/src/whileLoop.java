
import static java.lang.System.out;
import java.util.Scanner;


/*

Program: whileLoop.java          Last Date of this Revision: 20-Oct-2020

Purpose: 

Author: Your Name, 
School: CHHS
Course: Computer Programming 20
 
*/


public class whileLoop 
{

    public static void main(String[] args) 
    {
       Scanner keyboard = new Scanner(System.in);
       
        //prompt the user for a number
       out.print( "Please enter an integer number: " );
       int num = keyboard.nextInt();//record the number
       
       int i =0;
       
       while(i < num)//has to be true to enter the body of the loop
        {
            out.println(i);//i = 0 //i=1
            i++; //i = 1 // i = 2
                //i = i + 1;
                // i=1
                // i = 2
                // i = 3
                // i = 4
                // i = 5
        }
      
      
    }
}
/* Screen Dump
 

 
 */