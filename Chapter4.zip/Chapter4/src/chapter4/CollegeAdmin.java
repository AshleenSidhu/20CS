
/*

Program: CollegeAdmin.java          Last Date of this Revision: 13-Oct-2020

Purpose: 

Author: Your Name, 
School: CHHS
Course: Computer Programming 20
 
*/

package chapter4;

import java.util.Scanner;
import static java.lang.System.out;


public class CollegeAdmin 
{
    public static void main(String[] args) 
    {
        Scanner input = new Scanner(System.in); 
        
        int math;
        
        out.println("Welcome to the University of Carleton Admissions Application");
        out.println("Please enter your Math diploma score (200-800)");
        
        math = input.nextInt();
        
        
        
        out.print("Admittance status: ");
        
        if(math >= 790)
        {
            out.println("CERTAIN");
        }
        else if(math >= 710)
        {
           out.println("SAFE"); 
        }
        
        else if(math >= 580)
        {
            out.println("PROBABLE"); 
        }
        
        else if(math >= 390)
        {
           out.println("UNCERTAIN"); 
        }
        
        else
        {
            out.println("DENIED");
        }
        
    }
}
/* Screen Dump
 

 
 */