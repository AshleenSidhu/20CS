
/*

Program: Day_switch.java          Last Date of this Revision: 1-Mar-2021

Purpose: 

Author: 
School: CHHS
Course: Computer Science 20
 

*/

package chapter4;

import static java.lang.System.out;
import java.util.Scanner;


public class Day_switch 
{

    public static void main(String[] args) 
    {
        Scanner input = new Scanner(System.in); 
        
        int day;
        
        out.println("Please enter a number for the day of the week in order to get a name");
        day = input.nextInt();
        
        switch (day) 
        {
            case 1:
              System.out.println("Monday");
              break;
            case 2:
              System.out.println("Tuesday");
              break;
            case 3:
              System.out.println("Wednesday");
              break;
            case 4:
              System.out.println("Thursday");
              break;
            case 5:
              System.out.println("Friday");
              break;
            case 6:
              System.out.println("Saturday");
              break;
            case 7:
              System.out.println("Sunday");
              break;
              
            default:
                System.out.println("Please choose numbers between 1-7");
                break;
        }
    }
        
}
/* Screen Dump
 

 
 */
