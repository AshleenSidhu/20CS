/*

Program: Grad.java          Date: 8-Dec-2020


Author: Please enter your first and last name here 
School: CHHS
Course: Computer Science 10
 

*/

package chapter4;

import java.util.Scanner;


public class Grad 
{

    public static void main(String args[])
    {
                double gpa;		//grade point average
 		Scanner input = new Scanner(System.in);

 		/* Obtain gpa */
 		System.out.print ("Enter your grade point average: OR to Quit enter -1");
 		gpa = input.nextDouble();
 		
                
                while(gpa != -1)                        
                {

                    /* Determine honors distinction */
                    if (gpa >= 3.8)  
                    {
                            System.out.println("summa cum laude");
                            
                            System.out.print ("Enter another grade point average OR -1 to QUIT");
                            gpa = input.nextDouble();
                            
                            
                    } else if ((gpa < 3.8) && (gpa >= 3.65)) 
                    {
                            System.out.println("magna cum laude");
                            System.out.print ("Enter another grade point average OR -1 to QUIT");
                            gpa = input.nextDouble();
                            
                    } else if ((gpa < 3.65) && (gpa >= 3.5)) 
                    {
                            System.out.println("cum laude");
                            System.out.print ("Enter another grade point average OR -1 to QUIT");
                            gpa = input.nextDouble();
                            
                    } else 
                    {
                            System.out.println("You did not qualify for an honors distinction.");
                            System.out.print ("Enter another grade point average OR -1 to QUIT");
                            gpa = input.nextDouble();
                    }
                }
                System.out.println("Thank you for using our program. Bye!");
       
    }

}
/* Screen Dump
 


 
 */
