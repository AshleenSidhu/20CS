
import static java.lang.System.out;
import java.util.Scanner;

/*

Program: doWhile.java          Last Date of this Revision: 20-Oct-2020

Purpose: 

Author: Your Name, 
School: CHHS
Course: Computer Science 20
 

*/


public class doWhile 
{
    public static void main(String[] args) 
    {
      Scanner keyboard = new Scanner(System.in);
      int current, total = 0;
      out.print("Type in a bunch of values and I'll add them up. ");
      
      do
      {
            System.out.print("Value: ");
            current = keyboard.nextInt();
            total += current;//total = total + current;
      
      }while(current != 0);
      	
      System.out.println("The final total is: " + total);
    }
}
/* Screen Dump
 

 
 */
