


import java.util.Scanner;


public class Cities 
{
    public static void main(String[] args)
    {
        Scanner input = new Scanner(System.in);
        final String SENTINEL = "stop";
        String cityName;
        int numNames = 0;
        int mostChars = 0;
        String longestName = "";
        
        //Obtain city name
        System.out.print("Enter a city name ( " + SENTINEL + " to quit):");
        cityName = input.nextLine();
        
        //removes spaces before and after city name
        cityName = cityName.trim();
        
        //loop while the city does not equal the SENTINEL
        while(cityName.compareToIgnoreCase(SENTINEL) !=0)
        {
            numNames = numNames + 1;
            if(cityName.length() > mostChars)
            {
                //increment the city counter with new letter count
                mostChars = cityName.length();
                
                //reassign longest city with city name
                longestName = cityName;
            }
            //Ask the user to enter another city or quit
            System.out.print("Enter a city name ( " + SENTINEL + " to quit):");
            cityName = input.nextLine();
            cityName = cityName.trim();
        }
        //Display number of names entered and lonest name
        longestName = longestName.toUpperCase();
        System.out.print(numNames + " names were entered");
        System.out.print("The longest city name was: "+ longestName);
        
    }

}
