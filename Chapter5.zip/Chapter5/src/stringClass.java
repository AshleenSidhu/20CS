
import java.util.Scanner;


/*

Program: stringClass.java          Last Date of this Revision: 22-Oct-2020

Purpose: 

Author: Your Name, 
School: CHHS
Course: Computer Programming 20
 
*/


public class stringClass 
{
    public static void main(String[] args) 
    {
        String yourName = "Java";
        //System.out.println(yourName.length());
        //System.out.println(yourName.isEmpty());
        //System.out.println(yourName.substring(1));
        //System.out.println(yourName.toLowerCase());
        
        //System.out.print(yourName.replace("J", "L"));
       
        
         Scanner input = new Scanner(System.in);
         System.out.println("Please enter your full name: ");
         String myName = input.nextLine();
         //System.out.println(myName);
         
         if(yourName.equals(myName))
            System.out.println("True");  
         
         else
            System.out.println("False");
    }    
}
/* Screen Dump
 

 
 */