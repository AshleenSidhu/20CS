
/*

Program: TypeCasting.java          Last Date of this Revision: 6-Oct-2020

Purpose: 

Author: Your Name, 
School: CHHS
Course: Computer Programming 20
 
*/

package chapter3;


public class TypeCasting 
{
    public static void main(String[] args) 
    {
        int z = 8;
        double c = 5.6;
        double y = (double)z * c;
        System.out.println(y);


    }
}
/* Screen Dump
 

 
 */