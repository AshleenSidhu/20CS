
/*

Program: CarRecall.java          Last Date of this Revision: 15-Oct-2020

Purpose: 

Author: Your Name, 
School: CHHS
Course: Computer Programming 20
 
*/

package chapter4;

import java.util.Scanner;


public class CarRecall 
{
    public static void main(String[] args) 
    {
        int modelNumber;
        Scanner input = new Scanner(System.in);
        //obtain model number from user
        System.out.print("Enter the car's model number: ");
        modelNumber = input.nextInt();
        
        //match the modelNumber with a specific case
        switch (modelNumber) {
                                case 119:
                                case 179:
                                case 189:
                                case 190:
                                case 191:
                                case 192:
                                case 193:
                                case 194:
                                case 195:
                                case 221:
                                case 780:System.out.println("Your car is defective. It must be repaired."); break;
                                default: System.out.println("Your car is not defective."); break;

                            }
    }
}
/* Screen Dump
 

 
 */