
import java.util.Scanner;


/*

Program: forLoop.java          Last Date of this Revision: 21-Oct-2020

Purpose: 

Author: Your Name, 
School: CHHS
Course: Computer Programming 20
 
*/


public class forLoop 
{
    public static void main(String[] args) 
    {
        int max;
        int sum = 0;
	int step = 2; 
        Scanner input = new Scanner(System.in);
        
        //obtain a number from the user
        System.out.print("Enter a maximum value: ");
	max = input.nextInt();
        
        for(int i = 1; i<= max; i+= step)
        {
            sum = sum + i;
        }
       System.out.println("The sum of the odd numbers from 1 to " + max + " is: " + sum);
}
}
/* Screen Dump
 

 
 */