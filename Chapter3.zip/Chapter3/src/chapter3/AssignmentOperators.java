
/*

Program: AssignmentOperators.java          Last Date of this Revision: 6-Oct-2020

Purpose: 

Author: Your Name, 
School: CHHS
Course: Computer Programming 20
 
*/

package chapter3;


public class AssignmentOperators 
{
    public static void main(String[] args) 
    {
        final double PI = 3.14;
        
        
        int numPlayers = 12;
        System.out.println("numPlayers = "+numPlayers);
        
        
        
        
        
       
        numPlayers = numPlayers + 2;
        System.out.println("numPlayers = "+numPlayers);
        
        
        
        
        
        
        
        numPlayers += 1;
        
        System.out.println("numPlayers = "+numPlayers);

        
        
        
        
        
        
        
        numPlayers -= 5;
        
        System.out.println("numPlayers = "+numPlayers);
       
        
        
        
        
        
        
        
        
        int numOther = -2;
        
        numPlayers = numPlayers + numOther;
        
        System.out.println("numPlayers = "+numPlayers);
        
        
        
        numPlayers += numOther;
      System.out.println("numPlayers = "+numPlayers);

        
    }
}
/* Screen Dump
 

 
 */