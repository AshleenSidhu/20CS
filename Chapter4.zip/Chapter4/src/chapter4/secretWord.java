
/*

Program: secretWord.java          Last Date of this Revision: 13-Oct-2020

Purpose: 

Author: Your Name, 
School: CHHS
Course: Computer Programming 20
 
*/

package chapter4;

import java.util.Scanner;

import static java.lang.System.out;

public class secretWord 
{
    public static void main(String[] args) 
    {
        Scanner input = new Scanner(System.in); 
        
        String secret = "chhs";
        String guess;
        
        out.println("What's the secret word?");
        
        guess = input.next();
        
        
        if(guess.equals(secret))//true or false
        {
            out.println("That is correct!");            
        }
        else
        {
            out.println("That is not correct secret word.");  
        }
        
    }
}
/* Screen Dump
 

 
 */