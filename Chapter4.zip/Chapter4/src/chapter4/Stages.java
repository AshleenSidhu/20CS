
/*

Program: Stages.java          Last Date of this Revision: 15-Oct-2020

Purpose: 

Author: Your Name, 
School: CHHS
Course: Computer Programming 20
 
*/

package chapter4;

import java.util.Scanner;


public class Stages 
{
    public static void main(String[] args) 
    {
        
      int age;
      Scanner input = new Scanner(System.in); 
      //Obtain age from user
      System.out.print ("Enter your age: ");
      age = input.nextInt();//record age
      
      //Determine the stage associated with age
      if(age <= 5)
      {
        System.out.print ("toddler");

      }
      else
      {
        if(age <= 10)
          {
           System.out.print ("child");   
          }
          else
          {
              if(age <= 12)
              {
                System.out.print ("preteen");  
              }
              else
              {
                  if(age <= 18)
                  {
                     System.out.print ("teen"); 
                  }
                  else
                  {
                     System.out.print ("adult"); 
                  }
              }
          }
      }
 
      

    }
}
/* Screen Dump
 

 
 */