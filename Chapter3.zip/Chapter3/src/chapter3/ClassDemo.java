
/*

Program: ClassDemo.java          Last Date of this Revision: 29-Sep-2020

Purpose: 

Author: Your Name, 
School: CHHS
Course: Computer Programming 20
 
*/

package chapter3;

import java.util.Scanner;


public class ClassDemo 
{
    public static void main(String[] args) 
    {
        /*
        int x = 5;//assignment operator
        double y = 12;
        String name = "Lab 314";
        char z = 'A'; 
        
        System.out.println("This is number:"+x);
        System.out.println("x + y = "+ (x+y));
       System.out.println(name);
       System.out.println(z);
        
        
        
        Scanner input = new Scanner(System.in);
        System.out.println("Please enter any three digits: ");
        
        int userinput = input.nextInt();
        
        int f = userinput / 100;
        
        int s = (userinput % 100) / 10;
        
        int t = (userinput % 100) % 10;
        
        System.out.println("The first digit is: "+ f);
        
        System.out.println("The second digit is: "+ s);
        
        System.out.println("The third digit is: "+ t);

        System.out.println("5+6*4/2");
  */      
        
    }
}
/* Screen Dump
 
Please enter any three digits: 
984
The first digit is: 9
The second digit is: 8
The third digit is: 4
 
 */