/*

Program: passwd.java          Date: 8-Dec-2020


Author: Please enter your first and last name here 
School: CHHS
Course: Computer Science 10
 

*/

package chapter4;

import java.util.Scanner;


public class passwd 
{

    public static void main(String args[])
    {
                String userName, password;
		
                Scanner input = new Scanner(System.in);

		/* get user name */
		System.out.print("Enter a user name: ");
		userName = input.nextLine();
		

		/* get password */
		System.out.print("Enter a password that is at least 8 characters: ");
		password = input.next();
                
                
		//while loop condition
                while (password.length() < 5) 
                {
			System.out.print("Enter a password that is at least 5 characters: ");
			password = input.next();
		}
		

		System.out.println("Your user name is " + userName + " and your password is " + password);
       
    }

}
/* Screen Dump
 


 
 */
